# FinTeach

A financial education eLearning platform for young adults (15–20).

## Deployment Instructions
See README for deploying on Vercel.