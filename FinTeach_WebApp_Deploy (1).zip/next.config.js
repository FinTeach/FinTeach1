// Vercel configuration
module.exports = { reactStrictMode: true };