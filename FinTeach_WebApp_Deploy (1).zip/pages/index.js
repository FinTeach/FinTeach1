// Homepage
export default function Home() { return <div>Welcome to FinTeach!</div>; }