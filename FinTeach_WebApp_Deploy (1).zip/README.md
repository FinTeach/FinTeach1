# FinTeach Deployment Guide
1. Go to https://vercel.com/import
2. Upload this ZIP
3. Set your environment variables
4. Deploy!